USE project;

SELECT Gender, COUNT(*) AS Employees FROM HR
WHERE Attrition = 0
GROUP BY Gender;