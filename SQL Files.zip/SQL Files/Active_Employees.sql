USE project;

SELECT COUNT(*) AS Active_Employees 
FROM HR
WHERE Attrition = 0;