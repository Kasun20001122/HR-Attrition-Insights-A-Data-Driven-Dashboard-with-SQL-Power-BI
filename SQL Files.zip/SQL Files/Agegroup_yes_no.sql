USE project;

SELECT 
    CASE
        WHEN Age BETWEEN 18 AND 23 THEN '18-23'
        WHEN Age BETWEEN 24 AND 29 THEN '24-29'
        WHEN Age BETWEEN 30 AND 35 THEN '30-35'
        WHEN Age BETWEEN 36 AND 41 THEN '36-41'
        WHEN Age BETWEEN 42 AND 47 THEN '42-47'
        WHEN Age BETWEEN 48 AND 60 THEN '48-60'
        ELSE '60+'
    END AS Age_Group,
    
    COUNT(CASE WHEN Attrition = 1 THEN 'Yes' END) AS Attrition_Yes,
    COUNT(CASE WHEN Attrition = 0 THEN 'No' END) AS Attrition_No

FROM HR
GROUP BY 
    CASE
        WHEN Age BETWEEN 18 AND 23 THEN '18-23'
        WHEN Age BETWEEN 24 AND 29 THEN '24-29'
        WHEN Age BETWEEN 30 AND 35 THEN '30-35'
        WHEN Age BETWEEN 36 AND 41 THEN '36-41'
        WHEN Age BETWEEN 42 AND 47 THEN '42-47'
        WHEN Age BETWEEN 48 AND 60 THEN '48-60'
        ELSE '60+'
    END
ORDER BY Age_Group;
