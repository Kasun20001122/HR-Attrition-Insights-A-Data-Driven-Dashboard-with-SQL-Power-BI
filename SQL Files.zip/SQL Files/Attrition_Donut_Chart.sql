USE project;

SELECT Gender, COUNT(*) AS Employees FROM HR
WHERE Attrition = 1
GROUP BY Gender
ORDER BY COUNT(*) DESC;