USE project;

SELECT MaritalStatus,
 COUNT(CASE WHEN Attrition = 1 THEN 'Yes' END) AS Attrition_Yes,
 COUNT(CASE WHEN Attrition = 0 THEN 'No' END) AS Attrition_No
FROM HR
GROUP BY MaritalStatus
ORDER BY COUNT(Attrition);
