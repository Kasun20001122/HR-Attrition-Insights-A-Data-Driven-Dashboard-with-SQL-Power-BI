USE project;

SELECT COUNT(*) AS Total_Employees_Attrition 
FROM HR
WHERE Attrition = 1;