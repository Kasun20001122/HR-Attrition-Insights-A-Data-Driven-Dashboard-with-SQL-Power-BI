USE project;

SELECT COUNT(*) AS Total_Employess FROM HR;