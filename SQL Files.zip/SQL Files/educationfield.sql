USE project;

SELECT EducationField, COUNT(Attrition) AS Employees
FROM HR
GROUP BY EducationField
ORDER BY COUNT(Attrition);