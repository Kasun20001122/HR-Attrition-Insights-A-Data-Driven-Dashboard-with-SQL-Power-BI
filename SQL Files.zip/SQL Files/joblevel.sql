USE project;

SELECT JobLevel,COUNT(Attrition) AS Employees
FROM HR
GROUP BY JobLevel
ORDER BY COUNT(Attrition);
