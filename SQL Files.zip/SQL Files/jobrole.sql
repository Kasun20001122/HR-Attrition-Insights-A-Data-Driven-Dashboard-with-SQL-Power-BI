USE project;

SELECT JobRole,COUNT(Attrition) AS Employees
FROM HR
GROUP BY JobRole
ORDER BY COUNT(Attrition);
