USE project;

SELECT JobRole,
 COUNT(CASE WHEN Attrition = 1 THEN 'Yes' END) AS Attrition_Yes,
 COUNT(CASE WHEN Attrition = 0 THEN 'No' END) AS Attrition_No
FROM HR
GROUP BY JobRole
ORDER BY COUNT(Attrition);
