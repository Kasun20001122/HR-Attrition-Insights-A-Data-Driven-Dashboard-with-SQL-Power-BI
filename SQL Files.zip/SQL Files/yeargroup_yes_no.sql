USE project;

SELECT
    CASE 
        WHEN YearsAtCompany BETWEEN 0 AND 7 THEN '0-7'
        WHEN YearsAtCompany BETWEEN 8 AND 15 THEN '8-15'
        WHEN YearsAtCompany BETWEEN 16 AND 23 THEN '16-23'
        WHEN YearsAtCompany BETWEEN 24 AND 31 THEN '24-31'
        ELSE '32-40'
    END AS Years_Group,
	    COUNT(CASE WHEN Attrition = 1 THEN 'Yes' END) AS Attrition_Yes,
        COUNT(CASE WHEN Attrition = 0 THEN 'No' END) AS Attrition_No
FROM HR
GROUP BY CASE 
        WHEN YearsAtCompany BETWEEN 0 AND 7 THEN '0-7'
        WHEN YearsAtCompany BETWEEN 8 AND 15 THEN '8-15'
        WHEN YearsAtCompany BETWEEN 16 AND 23 THEN '16-23'
        WHEN YearsAtCompany BETWEEN 24 AND 31 THEN '24-31'
        ELSE '32-40'
    END
ORDER BY Years_Group;